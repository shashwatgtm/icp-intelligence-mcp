from pathlib import Path
import subprocess,json,hashlib,tarfile
root=Path('/workspace');w=root/'work/w5c';pdir=w/'patches';pdir.mkdir(exist_ok=True)
repos=['icp-intelligence-mcp','impact-mcp','craft-gtm-mcp','craft-content-mcp','gtm-alpha-secure','revenue-enablement-mcp'];manifest=[]
for repo in repos:
 r=root/repo
 files=['docs/'+('timing-tests-design-20261029.md' if repo=='revenue-enablement-mcp' else 'timing-tests-review-20261029.md')]
 if repo!='revenue-enablement-mcp':files+=['tests/helpers/cpu-budget.mjs','tests/'+('run22-echo-gaps.test.mjs' if repo=='craft-content-mcp' else 'run40s-escape.test.mjs')]
 subprocess.run(['git','add','--']+files,cwd=r,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=r,check=True)
 patch=subprocess.check_output(['git','diff','--cached','--binary','--full-index'],cwd=r);(pdir/(repo+'.patch')).write_bytes(patch)
 manifest.append(dict(repo=repo,base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),branch='codex/timing-tests-20261029',changed_files=files,files_sha256={f:hashlib.sha256((r/f).read_bytes()).hexdigest() for f in files},patch_sha256=hashlib.sha256(patch).hexdigest()))
(w/'manifest.json').write_text(json.dumps(manifest,indent=2))
archive=root/'icp-intelligence-mcp/docs/w5c-evidence-20261029.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(w.rglob('*')):
  if not p.is_file() or p.is_symlink():continue
  rel=p.relative_to(w)
  if rel.parts[0] in ['base','mutants'] and any(k in rel.parts for k in ['node_modules','dist','netlify','src']):continue
  tar.add(p,arcname=str(rel),recursive=False)
print('evidence bytes',archive.stat().st_size);print('sha256',hashlib.sha256(archive.read_bytes()).hexdigest())
subprocess.run(['git','add','docs/w5c-evidence-20261029.tar.gz'],cwd=root/'icp-intelligence-mcp',check=True)
