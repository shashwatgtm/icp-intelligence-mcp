from pathlib import Path
import subprocess,json,re,hashlib,shlex
ROOT=Path('/workspace');W=ROOT/'work/w5c'
records=json.loads((W/'receipts.json').read_text());mutants=json.loads((W/'mutant-receipts.json').read_text())
repos=['icp-intelligence-mcp','impact-mcp','craft-gtm-mcp','craft-content-mcp','gtm-alpha-secure','revenue-enablement-mcp']
branch='codex/timing-tests-20261029'
evidence='https://github.com/shashwatgtm/icp-intelligence-mcp/raw/refs/heads/codex/timing-tests-20261029/docs/w5c-evidence-20261029.tar.gz'
def stats(p):
 s=Path(p).read_text();return {k:int(re.search(r'^# '+k+r' (\d+)$',s,re.M).group(1)) for k in ['tests','pass','fail','skipped']}
def row(rec):
 t=stats(rec['log']);return f"| {rec.get('label',rec.get('mode'))} | {rec['exit']} | {t['pass']} | {t['fail']} | {t['skipped']} |"
refs='''## Documentation and UI scope

Read directly through the connected web tool on 29 October 2026:

- https://developers.openai.com/plugins/build/chatgpt-ui
- https://developers.openai.com/plugins/deploy/app-review

The coordinator independently read these pages and supplied the same findings. Direct cloud curl failed because the configured proxy refused connections. The connected web reader succeeded.

The UI guide favors MCP Apps fields and bridge messages. It uses `_meta.ui.resourceUri`, tool notifications, `tools/call` and `structuredContent`. The review page requires exact CSP domains. The coordinator also verified `ui/initialize`, `ui/notifications/initialized`, MIME `text/html;profile=mcp-app`, and resource `_meta.ui.csp` keys `connectDomains`, `resourceDomains` and `frameDomains`. Any later UI must check `event.source === parent`, treat received data as untrusted, and keep text-only hosts useful. Bundle assets and use empty domain lists when no network access is needed. Keep attachment on the existing named tool. Do not add a render tool. No checkout flow or durable user storage.

This patch changes tests and review evidence only. No browser check or screenshot was taken. There is no new UI to inspect. The existing text responses are exercised by direct local handler tests. No live endpoint was contacted.
'''
method='''## Measurement design

Correctness stays independent of timing. Keep every hostile value, legacy fixture, inertness assertion, ordinary-text assertion and long input. The four escape test files split the original combined test into a correctness test and a timing test. Content already has separate correctness tests.

The timing helper runs synchronous work in a worker thread. It warms every quarter-size and full-size input once. It then measures each size exactly once. It measures user plus system CPU time while the parent waits. This removes scheduling delay from the performance budget. GC and worker CPU still count. No result is selected from retries.

Keep the original numeric CPU ceilings: 250 ms for each full escape input, or 4000 ms for Content's full input set. Add a growth check: four times the input may use less than eight times the CPU. The small sample has a 5 ms floor to avoid timer noise. Linear work should approach four times. Quadratic work approaches sixteen times. The fixed ceiling still catches slower work below the growth floor.

The responsive parent terminates the worker after 15000 ms, including imports, warmup and measurement. This is a completion bound, not the CPU pass budget. The original escape budgets sum to 3500 ms for one full pass. Warmup and quarter-size work need additional time. Healthy busy runs remain well below the wall bound. A nonreturning mutant proves termination. This worker approach avoids this cloud's Node child-process restriction. It provides the same independent timeout property without a shell or child-process launch.

A process CPU clock also counts Node background threads. The helper assumes the calling test does not run other work concurrently in the same process. These top-level tests use Node's default sequential scheduling. Parallel test files normally have separate processes. Cloud receipts use in-process isolation with sequential tests because nested Node child execution is restricted.
'''
boundaries='''## Boundary audit

Only the new `codex/timing-tests-20261029` branch is used. No main or master write, force push, merge, ready-for-review transition, workflow dispatch, deployment, Netlify command or DNS change. No challenge file or its headers changed. No production algorithm, schema, output, endpoint, authentication, tool name, package version, dependency or hosted video changed. No submission, publication, package upload, legal declaration, OpenAI package skill, shell MCP tool, paid API call or agent was used. No credentials were read or printed. All checks ran in this cloud. Inputs are synthetic. Any company names already present in suite fixtures are review fixture inputs, not clients or prospects. No unrelated branch or user work was changed.
'''
for repo in repos:
 root=ROOT/repo;sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
 relevant=[r for r in records if r['repo']==repo]
 title='# W5c timing test review, 29 October 2026\n' if repo!='revenue-enablement-mcp' else '# W5c timing test design, 29 October 2026\n'
 intro=f'\nBase: `{sha}` on `{ "master" if repo=="gtm-alpha-secure" else "main" }`. The coordinator verified this SHA through GitHub at about 09:48 IST on 29 October 2026. Branch: `{branch}`. Runtime: Node 24.19.0. No runtime version was changed.\n'
 if repo=='revenue-enablement-mcp':intro+='\nDesign only. This is the only file changed in this repository. No source, build, test, schema or package change is applied. The existing base was built and tested. The implementation described below is proposed for later approval, after the current review boundary is lifted.\n'
 automation='''## Automation and delivery

Inspected tracked instructions, package scripts, netlify.toml and the complete GitHub tree at the verified base. No applicable AGENTS.md or workflow files were found. The GitHub workflow-list URL was rejected by the connector, so the complete nontruncated Git tree was used. Builds are TypeScript only, except Alpha's static-site script. No automation settings were changed.
'''
 if repo=='gtm-alpha-secure':automation+='\nHOLD remote branch and draft PR creation. The coordinator confirms master is git linked. No workflow files exist, but branch and PR preview settings cannot be verified through the available tools. An empty combined commit status does not prove previews are disabled. The full Alpha patch is in the evidence archive. The coordinator can finish delivery after verifying that it cannot trigger deployment.\n'
 else:automation+='\nThe coordinator confirms this site uses manual CLI deployment. A codex branch and draft PR are authorized. The connector will deliver the tested bytes because shell Git cannot connect to the cloud proxy. No deployment command is part of delivery.\n'
 receipts='## Test receipts\n\nCounts are individual Node tests, not file-only runner summaries. Existing suite skips are preserved. No skip was added. Preliminary default-runner logs are not accepted as receipts. Default isolation could report a file without reporting individual tests. The accepted runs use `--test-isolation=none`.\n\n| Run | Exit | Pass | Fail | Skip |\n| --- | --- | --- | --- | --- |\n'
 receipts+='\n'.join(row(r) for r in relevant)+'\n'
 if repo!='revenue-enablement-mcp':receipts+='\n'+ '\n'.join(row(r) for r in mutants if r['repo']==repo)+'\n'
 receipts+='\nBusy checks used `taskset -c 0` for the tests and two bounded Python CPU workers on CPU 0. The normal busy phase was capped at 240 seconds. The mutant phase was capped at 120 seconds. Both workers were stopped in a finally block after each phase. No live load testing occurred. The unchanged bases also passed in these conditions, so the intermittent failure was not reproduced in this run.\n'
 if repo!='revenue-enablement-mcp':
  receipts+='\nSlow mutants add 300 ms CPU to escape input 0, or 4500 ms CPU to Content input 0. Original output is retained. Isolated runs fail the CPU ceiling. Busy runs also fail; Content reaches the wall bound. Unsafe mutants return input unchanged and fail existing inertness assertions. A shared nonreturning mutant fails at the wall bound. An 80 ms quadratic mutant stays below 250 ms but fails the growth assertion. Mutants live only in the scratch evidence tree, never in production.\n'
 else:receipts+='\nNo mutant or proposed test was applied or run in Revenue. The five peer implementations provide experimental evidence for this design. Revenue receipts above are strictly unchanged-base receipts.\n'
 if repo=='gtm-alpha-secure':receipts+='\nThe two suite failures are unchanged `version-json.test.mjs` tests. Both fail with `spawnSync node EPERM`. Running that unchanged file alone gives 0 pass, 2 fail, 0 skip. A direct static build with a synthetic COMMIT_REF passes and writes the expected version JSON. Generated report files were restored to their original bytes after checks. The affected escape file passes all 12 tests. These environment failures were not fixed or skipped.\n'
 elif repo=='revenue-enablement-mcp':receipts+='\nThe suite has 30 existing skips. These include missing private/project fixtures and tests for an unported earlier ROI rewrite. No failure occurred.\n'
 receipts+='\nBuild command: `npm run build` (exit 0).' if repo!='gtm-alpha-secure' else '\nBuild command: `COMMIT_REF=0123456789abcdef0123456789abcdef01234567 node scripts/build-site.mjs` (exit 0).'
 receipts+='\n\nAccepted test commands, working directories, exit codes and complete TAP logs are in the [cloud evidence archive]('+evidence+'). The archive also includes the base scaffolds specification, mutation wrappers, harnesses, timing logs and Alpha patch. The JSON manifests retain exact argv, not reconstructed commands.\n\nMain test commands in this repository:\n\n```sh\n'
 f='tests/run22-echo-gaps.test.mjs' if repo=='craft-content-mcp' else 'tests/run40s-escape.test.mjs'
 if repo=='revenue-enablement-mcp':receipts+="node --test --test-isolation=none --test-reporter=tap --test-name-pattern='every escaped value is inert by itself|large and adversarial inputs run quickly' tests/run40s-escape.test.mjs\n"
 else:receipts+=f'node --test --test-isolation=none --test-reporter=tap {f}\n'
 receipts+='node --test --test-isolation=none --test-reporter=tap tests/*.test.mjs\n```\n'
 proposal=''
 if repo=='revenue-enablement-mcp':
  old=subprocess.check_output(['git','show','HEAD:tests/run40s-escape.test.mjs'],cwd=root)
  peer=subprocess.check_output(['git','show','HEAD:tests/run40s-escape.test.mjs'],cwd=ROOT/'icp-intelligence-mcp')
  assert old==peer
  diff=subprocess.check_output(['git','diff','--','tests/run40s-escape.test.mjs'],cwd=ROOT/'icp-intelligence-mcp',text=True)
  proposal='\n## Exact proposed test change, not applied\n\nThe base escape test is byte-identical to the ICP base test. Apply this diff later and add the helper below at `tests/helpers/cpu-budget.mjs`. No other production or package edit is required.\n\n```diff\n'+diff+'```\n\nProposed helper, complete file:\n\n```js\n'+(ROOT/'icp-intelligence-mcp/tests/helpers/cpu-budget.mjs').read_text()+'```\n'
  proposal+='\nExisting-base targeted TAP receipts:\n\n'
  for r in relevant:
   if r['label'] in ['base-isolated-actual','base-busy-actual']:proposal+='```text\n'+Path(r['log']).read_text()+'```\n'
 note=title+intro+'\n'+method+'\n'+receipts+'\n'+automation+'\n'+refs+'\n'+boundaries+proposal
 assert '\u2014' not in note and '\u2013' not in note
 path=root/'docs'/('timing-tests-design-20261029.md' if repo=='revenue-enablement-mcp' else 'timing-tests-review-20261029.md')
 path.parent.mkdir(exist_ok=True);path.write_text(note)
print('notes created')
