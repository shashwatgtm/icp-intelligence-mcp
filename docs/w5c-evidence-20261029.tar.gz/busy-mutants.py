from pathlib import Path
import subprocess,json,os
W=Path('/workspace/work/w5c');records=json.loads((W/'mutant-receipts.json').read_text());cpu=min(os.sched_getaffinity(0));loads=[]
try:
 for i in range(2):loads.append(subprocess.Popen(['taskset','-c',str(cpu),'python','-c','import time\nend=time.monotonic()+120\nx=1\nwhile time.monotonic()<end: x=(x*1664525+1013904223)%4294967296'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL))
 for rec in list(records):
  if rec['mode']=='hang':continue
  log=W/'logs'/f"{rec['repo']}-mutant-{rec['mode']}-busy.tap";cmd=['taskset','-c',str(cpu)]+rec['command']
  with log.open('w') as out:
   try:rc=subprocess.run(cmd,cwd=rec['cwd'],stdout=out,stderr=subprocess.STDOUT,timeout=25).returncode
   except subprocess.TimeoutExpired:rc=124;out.write('\nHARNESS TIMEOUT 25 seconds\n')
  records.append(dict(repo=rec['repo'],mode=rec['mode']+'-busy',command=cmd,cwd=rec['cwd'],exit=rc,log=str(log)));(W/'mutant-receipts.json').write_text(json.dumps(records,indent=2));print(rec['repo'],rec['mode']+'-busy',rc,flush=True)
finally:
 for p in loads:p.terminate()
 for p in loads:p.wait()
 (W/'mutant-load-receipt.json').write_text(json.dumps(dict(cpu=cpu,workers=2,maximum_seconds=120,stopped=[p.poll() is not None for p in loads]),indent=2))
