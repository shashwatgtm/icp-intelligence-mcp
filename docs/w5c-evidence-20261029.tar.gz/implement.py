from pathlib import Path
root=Path('/workspace')
helper='''// Run timing in a dedicated process so unrelated tests do not enter its CPU clock.
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";

const WORKER = `
  const { readFileSync } = await import("node:fs");
  const { moduleUrl, exportName, inputs } = JSON.parse(readFileSync(0, "utf8"));
  const fn = (await import(moduleUrl))[exportName];
  // One full warm pass. Every input is then measured once, without retries.
  for (const input of inputs) fn(input);
  const samples = [];
  for (const input of inputs) {
    const start = process.cpuUsage();
    const output = fn(input);
    const cpu = process.cpuUsage(start);
    if (typeof output !== "string") throw new Error("expected string output");
    samples.push((cpu.user + cpu.system) / 1000);
  }
  console.log(JSON.stringify(samples));
`;

export function assertCpuBudget(moduleUrl, exportName, inputs, budgetMs, aggregate = false) {
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", WORKER], {
    input: JSON.stringify({ moduleUrl: String(moduleUrl), exportName, inputs }),
    encoding: "utf8",
    // Hard wall bound includes import, warmup and measurement. Kill blocked code too.
    timeout: 15000,
    killSignal: "SIGKILL",
    maxBuffer: 65536,
  });
  assert.ifError(child.error);
  assert.equal(child.status, 0, `timing child failed (${child.signal}): ${child.stderr}`);
  const samples = JSON.parse(child.stdout);
  assert.equal(samples.length, inputs.length);
  const checked = aggregate ? [samples.reduce((a, b) => a + b, 0)] : samples;
  for (const [index, ms] of checked.entries()) {
    assert.ok(Number.isFinite(ms) && ms < budgetMs,
      `CPU budget exceeded: ${ms.toFixed(2)} ms >= ${budgetMs} ms (${aggregate ? "all inputs" : `input ${index}`})`);
  }
  console.log(`timing CPU ms: ${JSON.stringify(samples)}`);
}
'''
for repo in ['icp-intelligence-mcp','impact-mcp','craft-gtm-mcp','gtm-alpha-secure']:
 p=root/repo/'tests/run40s-escape.test.mjs'
 s=p.read_text().replace('import test from "node:test";','import test from "node:test";\nimport { assertCpuBudget } from "./helpers/cpu-budget.mjs";')
 start=s.index('  // linear: 200,000 characters')
 end=s.index('\n});',start)
 old=s[start:end]
 units=old[old.index('['):old.index(']) {')+1]
 replacement='''});

// Correctness above is independent of machine scheduling and performance below.
test("the escape pass: large adversarial inputs stay within the CPU budget", () => {
  const inputs = UNITS.map((unit) => unit.repeat(Math.ceil(200000 / unit.length)));
  assertCpuBudget(new URL(G ? "../netlify/lib/escape-inputs.js" : "../dist/escape-inputs.js", import.meta.url),
    "escapeText", inputs, 250);'''.replace('UNITS',units)
 s=s[:start]+replacement+s[end:]
 p.write_text(s)
 h=p.parent/'helpers/cpu-budget.mjs';h.parent.mkdir(exist_ok=True);h.write_text(helper)
p=root/'craft-content-mcp/tests/run22-echo-gaps.test.mjs'
s=p.read_text().replace('import test from "node:test";','import test from "node:test";\nimport { assertCpuBudget } from "./helpers/cpu-budget.mjs";')
s=s.replace('  const start = Date.now();\n  for (const i of inputs) neutraliseText(i);\n  const ms = Date.now() - start;\n  assert.ok(ms < 4000, `too slow: ${ms} ms`);','  assertCpuBudget(new URL(MODULE, import.meta.url), "neutraliseText", inputs, 4000, true);')
p.write_text(s);h=p.parent/'helpers/cpu-budget.mjs';h.parent.mkdir(exist_ok=True);h.write_text(helper)
