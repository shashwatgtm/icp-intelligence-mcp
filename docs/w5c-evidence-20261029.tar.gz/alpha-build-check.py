from pathlib import Path
import os,subprocess,json
root=Path('/workspace/gtm-alpha-secure')
ref='0123456789abcdef0123456789abcdef01234567'
env=dict(os.environ);env['COMMIT_REF']=ref
r=subprocess.run(['node','scripts/build-site.mjs'],cwd=root,env=env,capture_output=True,text=True)
print('command: COMMIT_REF=0123456789abcdef0123456789abcdef01234567 node scripts/build-site.mjs')
print('exit:',r.returncode);print(r.stdout);print(r.stderr)
if r.returncode==0:
 v=json.loads((root/'site/version.json').read_text());assert list(v)==['site','version','commit','built_utc'];assert v['commit']==ref;print('Synthetic commit build assertion: PASS')
