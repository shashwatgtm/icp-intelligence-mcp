from pathlib import Path
import subprocess,json,os,time
ROOT=Path('/workspace');W=ROOT/'work/w5c'; records=[]
repos=['icp-intelligence-mcp','impact-mcp','craft-gtm-mcp','craft-content-mcp','gtm-alpha-secure']
node=['node','--test','--test-isolation=none','--test-reporter=tap']
for repo in repos:
 content=repo=='craft-content-mcp';alpha=repo=='gtm-alpha-secure'
 f='run22-echo-gaps.test.mjs' if content else 'run40s-escape.test.mjs'
 target=ROOT/repo/('dist/echo-safe.js' if content else 'netlify/lib/escape-inputs.js' if alpha else 'dist/escape-inputs.js')
 export='neutraliseText' if content else 'escapeText'
 for mode in ['slow','unsafe']:
  d=W/'mutants'/repo/mode;(d/'tests').mkdir(parents=True,exist_ok=True)
  for name in ['netlify','dist','node_modules','src','package.json']:
   if (ROOT/repo/name).exists() and not (d/name).exists():(d/name).symlink_to(ROOT/repo/name,target_is_directory=(ROOT/repo/name).is_dir())
  for name in ['helpers','fixtures']:
   if (ROOT/repo/'tests'/name).exists() and not (d/'tests'/name).exists():(d/'tests'/name).symlink_to(ROOT/repo/'tests'/name,target_is_directory=True)
  wrapper=f'export * from {json.dumps(target.as_uri())};\nimport {{ {export} as original }} from {json.dumps(target.as_uri())};\n'
  if mode=='unsafe':wrapper+=f'export function {export}(input) {{ return input; }}\n'
  else:
   size=50000 if content else 200001 # first escape atom rounds up to 200001
   ms=4500 if content else 300
   wrapper+=f'''export function {export}(input) {{
  if (input.length === {size} && input.startsWith("[")) {{
    const start = process.cpuUsage();
    while (true) {{ const used=process.cpuUsage(start); if ((used.user+used.system)/1000 >= {ms}) break; }}
  }}
  return original(input);
}}
'''
  (d/'tests/mutant.mjs').write_text(wrapper)
  s=(ROOT/repo/'tests'/f).read_text()
  for old in ['../dist/escape-inputs.js','../netlify/lib/escape-inputs.js','../dist/echo-safe.js']:s=s.replace(old,'./mutant.mjs')
  (d/'tests'/f).write_text(s)
  pattern=('large and adversarial inputs run quickly' if content else 'CPU budget') if mode=='slow' else ('reference-style images are removed' if content else 'every escaped value is inert by itself')
  cmd=node+['--test-name-pattern='+pattern,'tests/'+f];log=W/'logs'/f'{repo}-mutant-{mode}.tap'
  with log.open('w') as out:
   try:rc=subprocess.run(cmd,cwd=d,stdout=out,stderr=subprocess.STDOUT,timeout=30).returncode
   except subprocess.TimeoutExpired:rc=124;out.write('\nHARNESS TIMEOUT 30 seconds\n')
  records.append(dict(repo=repo,mode=mode,command=cmd,cwd=str(d),exit=rc,log=str(log)));(W/'mutant-receipts.json').write_text(json.dumps(records,indent=2));print(repo,mode,rc,flush=True)
# A nonreturning synchronous mutant proves the parent wall bound terminates work.
d=W/'mutants/hang';d.mkdir(exist_ok=True)
(d/'hang.mjs').write_text('export function escapeText() { while (true) {} }\n')
(d/'check.mjs').write_text(f'import {{assertCpuBudget}} from {json.dumps((ROOT/repos[0]/"tests/helpers/cpu-budget.mjs").as_uri())};\nawait assertCpuBudget(new URL("./hang.mjs", import.meta.url), "escapeText", ["["], 250);\n')
with (W/'logs/hang-mutant.log').open('w') as out:
 start=time.monotonic();rc=subprocess.run(['node','check.mjs'],cwd=d,stdout=out,stderr=subprocess.STDOUT,timeout=25).returncode
records.append(dict(repo='helper',mode='hang',command=['node','check.mjs'],cwd=str(d),exit=rc,seconds=round(time.monotonic()-start,3)));(W/'mutant-receipts.json').write_text(json.dumps(records,indent=2));print('hang',rc,flush=True)
