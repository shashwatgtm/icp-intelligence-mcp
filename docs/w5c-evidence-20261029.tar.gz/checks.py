from pathlib import Path
import os,subprocess,json,sys,time
ROOT=Path('/workspace'); W=ROOT/'work/w5c'; LOG=W/'logs'
REPOS=['icp-intelligence-mcp','impact-mcp','craft-gtm-mcp','craft-content-mcp','gtm-alpha-secure','revenue-enablement-mcp']
records=[]
def run(repo,label,args,cwd=None,affinity=None):
 cmd=(['taskset','-c',str(affinity)] if affinity is not None else [])+args
 path=LOG/f'{repo}-{label}.tap'
 start=time.monotonic()
 with path.open('w') as out:
  try: rc=subprocess.run(cmd,cwd=cwd or ROOT/repo,stdout=out,stderr=subprocess.STDOUT,timeout=120).returncode
  except subprocess.TimeoutExpired: rc=124;out.write('\nHARNESS TIMEOUT 120 seconds\n')
 record=dict(repo=repo,label=label,command=cmd,cwd=str(cwd or ROOT/repo),exit=rc,seconds=round(time.monotonic()-start,3),log=str(path))
 records.append(record);(W/'receipts.json').write_text(json.dumps(records,indent=2));print(repo,label,rc,flush=True)

def scaffold(repo,label):
 d=W/label/repo; (d/'tests').mkdir(parents=True,exist_ok=True)
 for name in ['netlify','dist','node_modules','src','package.json']:
  p=d/name
  if not p.exists() and (ROOT/repo/name).exists(): p.symlink_to(ROOT/repo/name,target_is_directory=(ROOT/repo/name).is_dir())
 f='run22-echo-gaps.test.mjs' if repo=='craft-content-mcp' else 'run40s-escape.test.mjs'
 for name in ['fixtures','helpers']:
  p=d/'tests'/name
  if not p.exists() and (ROOT/repo/'tests'/name).exists():p.symlink_to(ROOT/repo/'tests'/name,target_is_directory=True)
 return d,f
base={}
for repo in REPOS:
 d,f=scaffold(repo,'base')
 s=subprocess.check_output(['git','show',f'HEAD:tests/{f}'],cwd=ROOT/repo,text=True)
 (d/'tests'/f).write_text(s);base[repo]=(d,f)
pattern='every escaped value is inert by itself|large and adversarial inputs run quickly'
node=['node','--test','--test-isolation=none','--test-reporter=tap']
for repo in REPOS:
 d,f=base[repo];run(repo,'base-isolated-actual',node+['--test-name-pattern='+pattern,'tests/'+f],d)
for repo in REPOS[:-1]:
 f=base[repo][1];run(repo,'changed-isolated-actual',node+['tests/'+f])
# Two bounded CPU workers share one allowed CPU with tests. No network traffic.
cpu=min(os.sched_getaffinity(0));loads=[]
try:
 for i in range(2):
  loads.append(subprocess.Popen(['taskset','-c',str(cpu),'python','-c','import time\nend=time.monotonic()+240\nx=1\nwhile time.monotonic()<end: x=(x*1664525+1013904223)%4294967296'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL))
 for repo in REPOS:
  d,f=base[repo];run(repo,'base-busy-actual',node+['--test-name-pattern='+pattern,'tests/'+f],d,cpu)
 for repo in REPOS[:-1]:
  f=base[repo][1];run(repo,'changed-busy-actual',node+['--test-name-pattern='+pattern+'|CPU budget','tests/'+f],affinity=cpu)
finally:
 for p in loads:p.terminate()
 for p in loads:p.wait()
 (W/'load-receipt.json').write_text(json.dumps(dict(cpu=cpu,workers=2,maximum_seconds=240,stopped=[p.poll() is not None for p in loads]),indent=2))
# Full application suites, same in-process runner. No live fetch calls in test sources.
for repo in REPOS:
 files=sorted(str(p.relative_to(ROOT/repo)) for p in (ROOT/repo/'tests').glob('*.test.mjs'))
 run(repo,'suite',node+files)
