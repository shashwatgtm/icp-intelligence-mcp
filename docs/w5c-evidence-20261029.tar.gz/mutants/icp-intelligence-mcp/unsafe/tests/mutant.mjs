export * from "file:///workspace/icp-intelligence-mcp/dist/escape-inputs.js";
import { escapeText as original } from "file:///workspace/icp-intelligence-mcp/dist/escape-inputs.js";
export function escapeText(input) { return input; }
