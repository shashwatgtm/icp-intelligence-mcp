export * from "file:///workspace/craft-gtm-mcp/dist/escape-inputs.js";
import { escapeText as original } from "file:///workspace/craft-gtm-mcp/dist/escape-inputs.js";
export function escapeText(input) { return input; }
