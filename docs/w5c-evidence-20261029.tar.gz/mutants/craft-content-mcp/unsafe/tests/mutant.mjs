export * from "file:///workspace/craft-content-mcp/dist/echo-safe.js";
import { neutraliseText as original } from "file:///workspace/craft-content-mcp/dist/echo-safe.js";
export function neutraliseText(input) { return input; }
