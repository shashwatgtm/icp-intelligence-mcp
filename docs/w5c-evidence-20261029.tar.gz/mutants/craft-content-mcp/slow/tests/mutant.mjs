export * from "file:///workspace/craft-content-mcp/dist/echo-safe.js";
import { neutraliseText as original } from "file:///workspace/craft-content-mcp/dist/echo-safe.js";
export function neutraliseText(input) {
  if (input.length === 50000 && input.startsWith("[")) {
    const start = process.cpuUsage();
    while (true) { const used=process.cpuUsage(start); if ((used.user+used.system)/1000 >= 4500) break; }
  }
  return original(input);
}
