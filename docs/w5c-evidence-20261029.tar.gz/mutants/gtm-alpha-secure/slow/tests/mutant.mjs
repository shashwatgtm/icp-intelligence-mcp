export * from "file:///workspace/gtm-alpha-secure/netlify/lib/escape-inputs.js";
import { escapeText as original } from "file:///workspace/gtm-alpha-secure/netlify/lib/escape-inputs.js";
export function escapeText(input) {
  if (input.length === 200001 && input.startsWith("[")) {
    const start = process.cpuUsage();
    while (true) { const used=process.cpuUsage(start); if ((used.user+used.system)/1000 >= 300) break; }
  }
  return original(input);
}
