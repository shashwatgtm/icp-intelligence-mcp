export * from "file:///workspace/gtm-alpha-secure/netlify/lib/escape-inputs.js";
import { escapeText as original } from "file:///workspace/gtm-alpha-secure/netlify/lib/escape-inputs.js";
export function escapeText(input) { return input; }
