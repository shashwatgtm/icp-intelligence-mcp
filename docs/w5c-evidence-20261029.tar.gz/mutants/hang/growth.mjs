export function escapeText(input) {
  const target = 80 * (input.length / 200000) ** 2;
  const start = process.cpuUsage();
  while (true) {
    const used = process.cpuUsage(start);
    if ((used.user + used.system) / 1000 >= target) break;
  }
  return input;
}
