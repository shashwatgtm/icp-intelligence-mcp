import { assertCpuBudget } from '/workspace/icp-intelligence-mcp/tests/helpers/cpu-budget.mjs';
await assertCpuBudget(new URL('./growth.mjs', import.meta.url), 'escapeText', ['['.repeat(200000)], 250);
