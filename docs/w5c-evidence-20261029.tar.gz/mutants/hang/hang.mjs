export function escapeText() { while (true) {} }
