import {assertCpuBudget} from "file:///workspace/icp-intelligence-mcp/tests/helpers/cpu-budget.mjs";
await assertCpuBudget(new URL("./hang.mjs", import.meta.url), "escapeText", ["["], 250);
